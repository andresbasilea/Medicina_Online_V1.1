// $(window).on("scroll", function() {
//   //console.log("scrollnig" + window.pageYOffset);
//   if (window.pageYOffset === 0 || window.pageYOffset < 50) {
//     //console.log("0")
//
//
//
//     $(".navbar").css("backgroundColor", "transparent");
//     $("a.nav-link.textoNav").css("visibility", "hidden");
//     $(".navbar-brand.navBar.textoNav.logo").css("color", "white");
//     $(".navbar-brand.navBar.textoNav.logo").css("font-size", "2.5rem");
//     $(".navbar-brand.navBar.textoNav.logo").css("text-shadow", "2px 2px 2px black");
//     // $("a.imagenNavBar").css("visibility", "visible");
//     // $("a.imagenNavBar").css("color", "white");
//       //$("a.imagenNavBar").css("text-shadow", "2px 2px 2px black");
//
//     $(".navbar").removeClass("bottom-border");
//
//
//   } else {
//
//
//     $(".navbar").css("backgroundColor", "white");
//     $(".navbar").css("opacity", "0.94");
//     $(".navbar-brand.navBar.textoNav.logo").css("font-size", "1.7rem");
//     $("a.nav-link.textoNav").css("visibility", "visible");
//     $(".navbar-brand.navBar.textoNav.logo").css("text-shadow", "0 0 0");
//     $("a.nav-link.textoNav").css("color", "#086972");
//     $("a.nav-link").css("visibility", "visible");
//     $(".navbar-brand.navBar.textoNav.logo").css("color", "#204051");
//     $("a.imagenNavBar").css("visibility", "visible");
//     $(".navbar").addClass("bottom-border");
//   }
//
//
// });
